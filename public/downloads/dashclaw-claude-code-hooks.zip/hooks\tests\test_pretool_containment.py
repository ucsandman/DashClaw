"""Integration tests for Containment Verdicts (allow_contained) in
dashclaw_pretool.py — capability advertisement + handle_allow_contained.

Follows the mock-HTTP-server + subprocess pattern from
test_pretool_integration.py. Each test that needs a real git repo creates one
in a fresh temp directory (via `git init` + an initial commit) so
`git worktree add` has a HEAD to branch from; tests are torn down by removing
the whole temp directory (which contains the worktree, since it lives at
<repo>/.dashclaw/contained/<seg>).

Uses only the Python standard library.
"""

import hashlib
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import unittest
import uuid
from http.server import HTTPServer, BaseHTTPRequestHandler

_HOOKS_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_PRETOOL_SCRIPT = os.path.join(_HOOKS_DIR, "dashclaw_pretool.py")


# ---------------------------------------------------------------------------
# Mock HTTP server (guard + actions)
# ---------------------------------------------------------------------------

class _RequestLog:
    def __init__(self):
        self.requests: list[dict] = []
        self._lock = threading.Lock()
        self.guard_response: dict = {"decision": "allow"}

    def add(self, method, path, body):
        bare, _, query = path.partition("?")
        with self._lock:
            self.requests.append({"method": method, "path": bare, "query": query, "body": body})

    def get_all(self):
        with self._lock:
            return list(self.requests)

    def clear(self):
        with self._lock:
            self.requests.clear()


def _make_handler(log: _RequestLog):
    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):
            length = int(self.headers.get("Content-Length", 0))
            raw = self.rfile.read(length) if length else b""
            body = json.loads(raw) if raw else None
            log.add("POST", self.path, body)

            if self.path.partition("?")[0] == "/api/guard":
                resp = json.dumps(log.guard_response).encode()
            elif self.path == "/api/actions":
                resp = json.dumps({"action_id": "test-action-fallback"}).encode()
            else:
                self.send_response(404)
                self.end_headers()
                return
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(resp)))
            self.end_headers()
            self.wfile.write(resp)

        def do_GET(self):
            log.add("GET", self.path, None)
            resp = json.dumps({"status": "running"}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(resp)))
            self.end_headers()
            self.wfile.write(resp)

        def log_message(self, fmt, *args):
            pass

    return Handler


def _find_free_port():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _run_hook(stdin_data, env_overrides=None, timeout=15):
    env = os.environ.copy()
    for key in list(env.keys()):
        if key.startswith("DASHCLAW_"):
            del env[key]
    # A developer with a real Neon setup exported would otherwise have the db
    # capability appended here (RFC 2026-09-04) and see these exact-equality
    # assertions fail where CI passes.
    for key in ("DATABASE_URL", "NEON_API_KEY", "NEON_PROJECT_ID", "PGHOST"):
        env.pop(key, None)
    env["DASHCLAW_DISABLE_DOTENV"] = "1"
    if env_overrides:
        env.update(env_overrides)

    proc = subprocess.run(
        [sys.executable, _PRETOOL_SCRIPT],
        input=json.dumps(stdin_data).encode("utf-8"),
        capture_output=True,
        timeout=timeout,
        env=env,
    )
    return proc.returncode, proc.stdout.decode("utf-8", errors="replace"), proc.stderr.decode("utf-8", errors="replace")


def _git(args, cwd, check=True):
    proc = subprocess.run(["git"] + args, cwd=cwd, capture_output=True, text=True)
    if check and proc.returncode != 0:
        raise AssertionError("git %s failed: %s" % (args, proc.stderr))
    return proc


def _make_repo():
    """Create a fresh temp git repo with one commit. Returns the repo dir."""
    repo_dir = tempfile.mkdtemp(prefix="dashclaw-containment-test-")
    _git(["init"], cwd=repo_dir)
    _git(["config", "user.email", "test@dashclaw.local"], cwd=repo_dir)
    _git(["config", "user.name", "DashClaw Test"], cwd=repo_dir)
    readme = os.path.join(repo_dir, "README.md")
    with open(readme, "w", encoding="utf-8") as f:
        f.write("test repo\n")
    _git(["add", "README.md"], cwd=repo_dir)
    _git(["commit", "-m", "init"], cwd=repo_dir)
    return repo_dir


def _worktree_list(repo_dir):
    return _git(["worktree", "list", "--porcelain"], cwd=repo_dir).stdout


def _cleanup_tempstate(*paths):
    for p in paths:
        try:
            os.remove(p)
        except OSError:
            pass


class TestPretoolContainment(unittest.TestCase):
    server: HTTPServer
    server_thread: threading.Thread
    log: _RequestLog
    base_url: str

    @classmethod
    def setUpClass(cls):
        cls.log = _RequestLog()
        port = _find_free_port()
        handler = _make_handler(cls.log)
        cls.server = HTTPServer(("127.0.0.1", port), handler)
        cls.server_thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.server_thread.start()
        cls.base_url = "http://127.0.0.1:%d" % port

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server_thread.join(timeout=5)

    def setUp(self):
        self.log.clear()
        self.log.guard_response = {"decision": "allow"}
        self._repos = []
        self._tool_use_ids = []

    def tearDown(self):
        for repo in self._repos:
            shutil.rmtree(repo, ignore_errors=True)
        for tool_use_id in self._tool_use_ids:
            _cleanup_tempstate(self._action_state_path_no_track(tool_use_id))

    def _action_state_path_no_track(self, tool_use_id):
        return os.path.join(
            tempfile.gettempdir(), "dashclaw_last_action_" + self._instance_suffix() + "_" + tool_use_id
        )

    def _new_repo(self):
        repo = _make_repo()
        self._repos.append(repo)
        return repo

    def _env(self, workspace, **extra):
        env = {
            "DASHCLAW_BASE_URL": self.base_url,
            "DASHCLAW_API_KEY": "test-key-123",
            "DASHCLAW_AGENT_ID": "test-agent",
            "DASHCLAW_HOOK_MODE": "enforce",
            "DASHCLAW_WORKSPACE": workspace,
            "DASHCLAW_PERMISSION_MODE": "danger",
        }
        env.update(extra)
        return env

    def _instance_suffix(self):
        # Mirrors dashclaw_pretool.py's _INSTANCE_STATE_SUFFIX: sha256(BASE_URL
        # + "|" + AGENT_ID)[:12]. Every test uses self.base_url + "test-agent"
        # (see _env below), so the suffix is constant per test-class run.
        return hashlib.sha256((self.base_url + "|" + "test-agent").encode("utf-8")).hexdigest()[:12]

    def _action_state_path(self, tool_use_id):
        self._tool_use_ids.append(tool_use_id)
        return os.path.join(
            tempfile.gettempdir(), "dashclaw_last_action_" + self._instance_suffix() + "_" + tool_use_id
        )

    def _contained_seg(self, session_id):
        # Local-fallback branch segment (server sent no containment.ref):
        # session id + "-" + instance suffix, mirroring
        # _ensure_containment_worktree's co-installed-instance namespacing.
        return session_id + "-" + self._instance_suffix()

    # -----------------------------------------------------------------------
    # 1. Worktree created + exclude line + instructive deny (Write, rewrite off)
    # -----------------------------------------------------------------------

    def test_worktree_created_exclude_line_instructive_deny(self):
        repo = self._new_repo()
        session_id = "sess-" + uuid.uuid4().hex[:8]
        tool_use_id = "tu-1-" + uuid.uuid4().hex[:8]
        self._action_state_path(tool_use_id)

        self.log.guard_response = {
            "decision": "allow_contained",
            "recorded": True,
            "action_id": "act-contained-1",
            "containment": {"status": "contained", "basis": "file"},
        }

        code, stdout, stderr = _run_hook(
            {
                "tool_name": "Write",
                "tool_input": {"file_path": os.path.join(repo, "foo.txt"), "content": "hello"},
                "tool_use_id": tool_use_id,
                "session_id": session_id,
            },
            self._env(repo, DASHCLAW_CONTAINMENT_REWRITE="0"),
        )

        self.assertEqual(code, 2, "instructive deny exits 2; stderr=%s" % stderr)
        self.assertIn("containment ref", stderr)

        expected_worktree = os.path.join(repo, ".dashclaw", "contained", self._contained_seg(session_id))
        self.assertIn(expected_worktree, stderr)
        self.assertTrue(os.path.isdir(expected_worktree), "worktree directory should exist on disk")

        wt_list = _worktree_list(repo)
        self.assertIn(expected_worktree.replace("\\", "/"), wt_list.replace("\\", "/"))
        self.assertIn("dashclaw/contained-" + self._contained_seg(session_id), wt_list)

        exclude_path = os.path.join(repo, ".git", "info", "exclude")
        self.assertTrue(os.path.isfile(exclude_path))
        with open(exclude_path, encoding="utf-8") as f:
            exclude_content = f.read()
        self.assertIn(".dashclaw/", exclude_content)

        # .gitignore must never be touched.
        self.assertFalse(os.path.exists(os.path.join(repo, ".gitignore")))

        # PostToolUse state (Task 10 consumes this): action_id + containment_ref.
        with open(self._action_state_path(tool_use_id), encoding="utf-8") as f:
            state = json.loads(f.read())
        self.assertEqual(state["action_id"], "act-contained-1")
        self.assertEqual(state["containment_ref"], "dashclaw/contained-" + self._contained_seg(session_id))
        self.assertEqual(state["containment_worktree"], expected_worktree)

        # F1: base_sha (the worktree's HEAD at creation) is recorded so
        # PostToolUse can later diff the cumulative base..HEAD range.
        expected_base_sha = _git(["rev-parse", "HEAD"], cwd=repo).stdout.strip()
        self.assertEqual(state["containment_base_sha"], expected_base_sha)

    # -----------------------------------------------------------------------
    # 1b. base_sha stays fixed across reused-worktree calls (F1)
    # -----------------------------------------------------------------------

    def test_base_sha_recorded_and_stable_across_reuse(self):
        repo = self._new_repo()
        session_id = "sess-" + uuid.uuid4().hex[:8]
        expected_base_sha = _git(["rev-parse", "HEAD"], cwd=repo).stdout.strip()

        self.log.guard_response = {
            "decision": "allow_contained",
            "recorded": True,
            "action_id": "act-basesha-1",
            "containment": {"status": "contained", "basis": "file"},
        }
        tool_use_id_1 = "tu-basesha-1-" + uuid.uuid4().hex[:8]
        self._action_state_path(tool_use_id_1)
        code1, _, _ = _run_hook(
            {
                "tool_name": "Write",
                "tool_input": {"file_path": os.path.join(repo, "one.txt"), "content": "one"},
                "tool_use_id": tool_use_id_1,
                "session_id": session_id,
            },
            self._env(repo, DASHCLAW_CONTAINMENT_REWRITE="0"),
        )
        self.assertEqual(code1, 2)
        with open(self._action_state_path(tool_use_id_1), encoding="utf-8") as f:
            state1 = json.loads(f.read())
        self.assertEqual(state1["containment_base_sha"], expected_base_sha)

        self.log.guard_response = {
            "decision": "allow_contained",
            "recorded": True,
            "action_id": "act-basesha-2",
            "containment": {"status": "contained", "basis": "file"},
        }
        tool_use_id_2 = "tu-basesha-2-" + uuid.uuid4().hex[:8]
        self._action_state_path(tool_use_id_2)
        code2, _, _ = _run_hook(
            {
                "tool_name": "Write",
                "tool_input": {"file_path": os.path.join(repo, "two.txt"), "content": "two"},
                "tool_use_id": tool_use_id_2,
                "session_id": session_id,
            },
            self._env(repo, DASHCLAW_CONTAINMENT_REWRITE="0"),
        )
        self.assertEqual(code2, 2)
        with open(self._action_state_path(tool_use_id_2), encoding="utf-8") as f:
            state2 = json.loads(f.read())
        # Same session -> reused worktree -> same base_sha recorded at creation.
        self.assertEqual(state2["containment_base_sha"], expected_base_sha)

    # -----------------------------------------------------------------------
    # 2. Second contained call, same session -> worktree reused
    # -----------------------------------------------------------------------

    def test_second_contained_call_reuses_worktree(self):
        repo = self._new_repo()
        session_id = "sess-" + uuid.uuid4().hex[:8]

        self.log.guard_response = {
            "decision": "allow_contained",
            "recorded": True,
            "action_id": "act-contained-2a",
            "containment": {"status": "contained", "basis": "file"},
        }

        tool_use_id_1 = "tu-2a-" + uuid.uuid4().hex[:8]
        self._action_state_path(tool_use_id_1)
        code1, _, stderr1 = _run_hook(
            {
                "tool_name": "Write",
                "tool_input": {"file_path": os.path.join(repo, "one.txt"), "content": "one"},
                "tool_use_id": tool_use_id_1,
                "session_id": session_id,
            },
            self._env(repo, DASHCLAW_CONTAINMENT_REWRITE="0"),
        )
        self.assertEqual(code1, 2)

        wt_list_after_first = _worktree_list(repo)
        # Exactly one contained worktree line beyond the main repo worktree.
        self.assertEqual(wt_list_after_first.count("worktree "), 2)

        self.log.guard_response = {
            "decision": "allow_contained",
            "recorded": True,
            "action_id": "act-contained-2b",
            "containment": {"status": "contained", "basis": "file"},
        }
        tool_use_id_2 = "tu-2b-" + uuid.uuid4().hex[:8]
        self._action_state_path(tool_use_id_2)
        code2, _, stderr2 = _run_hook(
            {
                "tool_name": "Write",
                "tool_input": {"file_path": os.path.join(repo, "two.txt"), "content": "two"},
                "tool_use_id": tool_use_id_2,
                "session_id": session_id,
            },
            self._env(repo, DASHCLAW_CONTAINMENT_REWRITE="0"),
        )
        self.assertEqual(code2, 2)

        expected_worktree = os.path.join(repo, ".dashclaw", "contained", self._contained_seg(session_id))
        self.assertIn(expected_worktree, stderr1)
        self.assertIn(expected_worktree, stderr2, "second call must reuse the SAME worktree path")

        # No second `git worktree add` happened: still exactly one contained worktree.
        wt_list_after_second = _worktree_list(repo)
        self.assertEqual(wt_list_after_second.count("worktree "), 2)
        self.assertEqual(wt_list_after_first, wt_list_after_second)

    # -----------------------------------------------------------------------
    # 3. Not a git repo -> fail toward interruption, no worktree
    # -----------------------------------------------------------------------

    def test_not_a_git_repo_fails_toward_interruption(self):
        plain_dir = tempfile.mkdtemp(prefix="dashclaw-containment-nongit-")
        self._repos.append(plain_dir)
        session_id = "sess-" + uuid.uuid4().hex[:8]
        tool_use_id = "tu-3-" + uuid.uuid4().hex[:8]
        self._action_state_path(tool_use_id)

        self.log.guard_response = {
            "decision": "allow_contained",
            "recorded": True,
            "action_id": "act-contained-3",
            "containment": {"status": "contained", "basis": "shell_file_ops"},
        }

        code, _, stderr = _run_hook(
            {
                "tool_name": "Bash",
                "tool_input": {"command": "echo hi > out.txt"},
                "tool_use_id": tool_use_id,
                "session_id": session_id,
            },
            self._env(plain_dir),
        )

        self.assertEqual(code, 2)
        lowered = stderr.lower()
        self.assertTrue("interrupt" in lowered or "fail" in lowered, stderr)
        self.assertFalse(os.path.isdir(os.path.join(plain_dir, ".dashclaw")))

    # -----------------------------------------------------------------------
    # 4. Capability advertisement gating matrix
    # -----------------------------------------------------------------------

    def test_capability_advertised_when_enforce_git_repo_containable_tool(self):
        repo = self._new_repo()
        tool_use_id = "tu-4a-" + uuid.uuid4().hex[:8]
        self._action_state_path(tool_use_id)
        code, _, _ = _run_hook(
            {
                "tool_name": "Bash",
                "tool_input": {"command": "echo hi"},
                "tool_use_id": tool_use_id,
                "session_id": "sess-4a",
            },
            self._env(repo),
        )
        self.assertEqual(code, 0)
        body = [r for r in self.log.get_all() if r["path"] == "/api/guard"][-1]["body"]
        self.assertEqual(body.get("client_capabilities"), ["allow_contained"])
        # Instance discriminator rides alongside the capability so the server
        # can namespace the containment ref per co-installed hook instance.
        self.assertEqual(body.get("containment_instance"), self._instance_suffix())

    def test_capability_advertised_for_write_tool(self):
        """Same gating matrix, a second containable tool (Write, not Bash)."""
        repo = self._new_repo()
        tool_use_id = "tu-4a2-" + uuid.uuid4().hex[:8]
        self._action_state_path(tool_use_id)
        code, _, _ = _run_hook(
            {
                "tool_name": "Write",
                "tool_input": {"file_path": os.path.join(repo, "cap.txt"), "content": "x"},
                "tool_use_id": tool_use_id,
                "session_id": "sess-4a2",
            },
            self._env(repo),
        )
        self.assertEqual(code, 0)
        body = [r for r in self.log.get_all() if r["path"] == "/api/guard"][-1]["body"]
        self.assertEqual(body.get("client_capabilities"), ["allow_contained"])

    def test_capability_absent_when_containment_disabled(self):
        repo = self._new_repo()
        tool_use_id = "tu-4b-" + uuid.uuid4().hex[:8]
        self._action_state_path(tool_use_id)
        code, _, _ = _run_hook(
            {
                "tool_name": "Bash",
                "tool_input": {"command": "echo hi"},
                "tool_use_id": tool_use_id,
                "session_id": "sess-4b",
            },
            self._env(repo, DASHCLAW_CONTAINMENT="0"),
        )
        self.assertEqual(code, 0)
        body = [r for r in self.log.get_all() if r["path"] == "/api/guard"][-1]["body"]
        self.assertNotIn("client_capabilities", body)

    def test_capability_absent_in_observe_mode(self):
        repo = self._new_repo()
        tool_use_id = "tu-4c-" + uuid.uuid4().hex[:8]
        self._action_state_path(tool_use_id)
        code, _, _ = _run_hook(
            {
                "tool_name": "Bash",
                "tool_input": {"command": "echo hi"},
                "tool_use_id": tool_use_id,
                "session_id": "sess-4c",
            },
            self._env(repo, DASHCLAW_HOOK_MODE="observe"),
        )
        self.assertEqual(code, 0)
        body = [r for r in self.log.get_all() if r["path"] == "/api/guard"][-1]["body"]
        self.assertNotIn("client_capabilities", body)

    def test_capability_absent_when_not_git_repo(self):
        plain_dir = tempfile.mkdtemp(prefix="dashclaw-containment-nongit2-")
        self._repos.append(plain_dir)
        tool_use_id = "tu-4d-" + uuid.uuid4().hex[:8]
        self._action_state_path(tool_use_id)
        code, _, _ = _run_hook(
            {
                "tool_name": "Bash",
                "tool_input": {"command": "echo hi"},
                "tool_use_id": tool_use_id,
                "session_id": "sess-4d",
            },
            self._env(plain_dir),
        )
        self.assertEqual(code, 0)
        body = [r for r in self.log.get_all() if r["path"] == "/api/guard"][-1]["body"]
        self.assertNotIn("client_capabilities", body)

    # -----------------------------------------------------------------------
    # 4b. Observe mode never blocks, even if the server sends allow_contained
    #     (defense-in-depth against version skew / a misconfigured server).
    # -----------------------------------------------------------------------

    def test_observe_mode_never_blocks_on_allow_contained(self):
        repo = self._new_repo()
        tool_use_id = "tu-4e-" + uuid.uuid4().hex[:8]
        self._action_state_path(tool_use_id)

        self.log.guard_response = {
            "decision": "allow_contained",
            "recorded": True,
            "action_id": "act-contained-observe",
            "containment": {"status": "contained", "basis": "shell_file_ops"},
        }

        code, _, stderr = _run_hook(
            {
                "tool_name": "Bash",
                "tool_input": {"command": "echo hi > out.txt"},
                "tool_use_id": tool_use_id,
                "session_id": "sess-4e",
            },
            self._env(repo, DASHCLAW_HOOK_MODE="observe"),
        )

        self.assertEqual(code, 0, "observe mode must never block; stderr=%s" % stderr)
        self.assertFalse(os.path.isdir(os.path.join(repo, ".dashclaw")),
                          "observe mode must not create a containment worktree")

    # -----------------------------------------------------------------------
    # 5. Rewrite path: updatedInput hookSpecificOutput, exit 0
    # -----------------------------------------------------------------------

    def test_rewrite_emits_hook_specific_output_and_exits_zero(self):
        repo = self._new_repo()
        session_id = "sess-" + uuid.uuid4().hex[:8]
        tool_use_id = "tu-5-" + uuid.uuid4().hex[:8]
        self._action_state_path(tool_use_id)

        self.log.guard_response = {
            "decision": "allow_contained",
            "recorded": True,
            "action_id": "act-contained-5",
            "containment": {"status": "contained", "basis": "file"},
        }

        target = os.path.join(repo, "sub", "bar.txt")
        code, stdout, stderr = _run_hook(
            {
                "tool_name": "Write",
                "tool_input": {"file_path": target, "content": "hi there"},
                "tool_use_id": tool_use_id,
                "session_id": session_id,
            },
            self._env(repo, DASHCLAW_CONTAINMENT_REWRITE="1"),
        )

        self.assertEqual(code, 0, "rewrite path must exit 0; stderr=%s" % stderr)
        payload = json.loads(stdout)
        out = payload["hookSpecificOutput"]
        self.assertEqual(out["hookEventName"], "PreToolUse")
        self.assertEqual(out["permissionDecision"], "allow")
        self.assertIn("permissionDecisionReason", out)

        expected_worktree = os.path.join(repo, ".dashclaw", "contained", self._contained_seg(session_id))
        expected_path = os.path.join(expected_worktree, "sub", "bar.txt")
        updated = out["updatedInput"]
        self.assertEqual(updated["file_path"], expected_path)
        # All original fields preserved (complete replacement object).
        self.assertEqual(updated["content"], "hi there")

        self.assertTrue(os.path.isdir(expected_worktree))

    # -----------------------------------------------------------------------
    # 6. Worktree-escape regression (invariant 1): a rewrite must never place
    #    a path outside the repo into the worktree just because the server
    #    said allow_contained.
    # -----------------------------------------------------------------------

    def test_rewrite_rejects_path_outside_repo(self):
        repo = self._new_repo()
        session_id = "sess-" + uuid.uuid4().hex[:8]

        outside_dir = tempfile.mkdtemp(prefix="dashclaw-containment-outside-")
        self._repos.append(outside_dir)
        outside_target = os.path.join(outside_dir, "escape.txt")

        self.log.guard_response = {
            "decision": "allow_contained",
            "recorded": True,
            "action_id": "act-contained-escape",
            "containment": {"status": "contained", "basis": "file"},
        }

        tool_use_id = "tu-6-" + uuid.uuid4().hex[:8]
        self._action_state_path(tool_use_id)
        code, stdout, stderr = _run_hook(
            {
                "tool_name": "Write",
                "tool_input": {"file_path": outside_target, "content": "escape"},
                "tool_use_id": tool_use_id,
                "session_id": session_id,
            },
            self._env(repo, DASHCLAW_CONTAINMENT_REWRITE="1"),
        )

        self.assertEqual(code, 2, "a path outside the repo must instructive-deny, not rewrite; stderr=%s" % stderr)
        self.assertNotIn("updatedInput", stdout)
        self.assertEqual(stdout, "")

        if os.name == "nt":
            # Cross-drive path: os.path.relpath raises ValueError on
            # mismatched drive letters -- a pure string comparison, no
            # filesystem I/O, so this doesn't require a second drive to
            # actually exist on disk.
            repo_drive = os.path.splitdrive(repo)[0].upper()
            other_drive = "Z:" if repo_drive != "Z:" else "Y:"
            tool_use_id_2 = "tu-6b-" + uuid.uuid4().hex[:8]
            self._action_state_path(tool_use_id_2)
            code2, stdout2, stderr2 = _run_hook(
                {
                    "tool_name": "Write",
                    "tool_input": {"file_path": other_drive + "\\escape\\file.txt", "content": "escape"},
                    "tool_use_id": tool_use_id_2,
                    "session_id": session_id,
                },
                self._env(repo, DASHCLAW_CONTAINMENT_REWRITE="1"),
            )
            self.assertEqual(code2, 2, "cross-drive path must instructive-deny; stderr=%s" % stderr2)
            self.assertNotIn("updatedInput", stdout2)
            self.assertEqual(stdout2, "")

    # -----------------------------------------------------------------------
    # 7. DASHCLAW_CONTAINMENT=0 is a full kill switch, not just a capability-
    #    advertisement toggle: a server that still emits allow_contained
    #    (version skew) must not cause ANY worktree creation.
    # -----------------------------------------------------------------------

    def test_containment_disabled_is_full_kill_switch_in_enforce_mode(self):
        repo = self._new_repo()
        session_id = "sess-" + uuid.uuid4().hex[:8]
        tool_use_id = "tu-7-" + uuid.uuid4().hex[:8]
        self._action_state_path(tool_use_id)

        self.log.guard_response = {
            "decision": "allow_contained",
            "recorded": True,
            "action_id": "act-contained-killswitch",
            "containment": {"status": "contained", "basis": "file"},
        }

        code, stdout, stderr = _run_hook(
            {
                "tool_name": "Write",
                "tool_input": {"file_path": os.path.join(repo, "foo.txt"), "content": "hello"},
                "tool_use_id": tool_use_id,
                "session_id": session_id,
            },
            self._env(repo, DASHCLAW_CONTAINMENT="0"),
        )

        self.assertEqual(code, 2, "kill switch must still interrupt in enforce mode; stderr=%s" % stderr)
        self.assertIn("dashclaw_containment=0", stderr.lower())
        self.assertFalse(os.path.isdir(os.path.join(repo, ".dashclaw")),
                          "no worktree may be created while containment is disabled")

        with open(self._action_state_path(tool_use_id), encoding="utf-8") as f:
            state = json.loads(f.read())
        self.assertIsNone(state["containment_ref"])
        self.assertIsNone(state["containment_worktree"])
        self.assertEqual(state["action_id"], "act-contained-killswitch")


    # -----------------------------------------------------------------------
    # 8. Server-stamped containment_ref (security follow-up, RFC 2026-07-06):
    #    the guard response's containment.ref names the worktree branch, so
    #    the branch the hook creates is exactly the merge target the server
    #    stamped on the recorded action at ?record=true time.
    # -----------------------------------------------------------------------

    def test_server_provided_ref_is_adopted_for_the_worktree_branch(self):
        repo = self._new_repo()
        session_id = "sess-" + uuid.uuid4().hex[:8]
        server_seg = "srv-" + uuid.uuid4().hex[:8]
        tool_use_id = "tu-8-" + uuid.uuid4().hex[:8]
        self._action_state_path(tool_use_id)

        self.log.guard_response = {
            "decision": "allow_contained",
            "recorded": True,
            "action_id": "act-contained-8",
            "containment": {"status": "contained", "basis": "file",
                            "ref": "dashclaw/contained-" + server_seg},
        }

        code, _, stderr = _run_hook(
            {
                "tool_name": "Write",
                "tool_input": {"file_path": os.path.join(repo, "foo.txt"), "content": "hello"},
                "tool_use_id": tool_use_id,
                "session_id": session_id,
            },
            self._env(repo, DASHCLAW_CONTAINMENT_REWRITE="0"),
        )

        self.assertEqual(code, 2, "instructive deny exits 2; stderr=%s" % stderr)
        expected_worktree = os.path.join(repo, ".dashclaw", "contained", server_seg)
        self.assertTrue(os.path.isdir(expected_worktree),
                        "worktree must live under the SERVER's segment, not the local session's")
        self.assertIn("dashclaw/contained-" + server_seg, _worktree_list(repo))

        with open(self._action_state_path(tool_use_id), encoding="utf-8") as f:
            state = json.loads(f.read())
        self.assertEqual(state["containment_ref"], "dashclaw/contained-" + server_seg)
        self.assertEqual(state["containment_worktree"], expected_worktree)

    def test_malformed_server_ref_falls_back_to_local_derivation(self):
        repo = self._new_repo()
        session_id = "sess-" + uuid.uuid4().hex[:8]
        tool_use_id = "tu-8b-" + uuid.uuid4().hex[:8]
        self._action_state_path(tool_use_id)

        self.log.guard_response = {
            "decision": "allow_contained",
            "recorded": True,
            "action_id": "act-contained-8b",
            # No dashclaw/contained- prefix -> never adopted as a branch name.
            "containment": {"status": "contained", "basis": "file", "ref": "evil/../../ref"},
        }

        code, _, stderr = _run_hook(
            {
                "tool_name": "Write",
                "tool_input": {"file_path": os.path.join(repo, "foo.txt"), "content": "hello"},
                "tool_use_id": tool_use_id,
                "session_id": session_id,
            },
            self._env(repo, DASHCLAW_CONTAINMENT_REWRITE="0"),
        )

        self.assertEqual(code, 2, "instructive deny exits 2; stderr=%s" % stderr)
        expected_worktree = os.path.join(repo, ".dashclaw", "contained", self._contained_seg(session_id))
        self.assertTrue(os.path.isdir(expected_worktree))

        with open(self._action_state_path(tool_use_id), encoding="utf-8") as f:
            state = json.loads(f.read())
        self.assertEqual(state["containment_ref"], "dashclaw/contained-" + self._contained_seg(session_id))

    # -----------------------------------------------------------------------
    # Server-stamped ref adoption (v5.6.1): when the guard response carries
    # containment.ref, the hook creates the branch/worktree under the SERVER's
    # name — including a server-namespaced instance suffix — instead of the
    # local fallback derivation.
    # -----------------------------------------------------------------------

    def test_server_stamped_ref_names_the_branch_and_worktree(self):
        repo = self._new_repo()
        session_id = "sess-adopt-" + uuid.uuid4().hex[:8]
        tool_use_id = "tu-adopt-" + uuid.uuid4().hex[:8]
        self._action_state_path(tool_use_id)
        server_ref = "dashclaw/contained-%s-%s" % (session_id, self._instance_suffix())

        self.log.guard_response = {
            "decision": "allow_contained",
            "recorded": True,
            "action_id": "act-adopt-1",
            "containment": {"status": "contained", "basis": "file", "ref": server_ref},
        }

        code, _, stderr = _run_hook(
            {
                "tool_name": "Write",
                "tool_input": {"file_path": os.path.join(repo, "foo.txt"), "content": "hello"},
                "tool_use_id": tool_use_id,
                "session_id": session_id,
            },
            self._env(repo, DASHCLAW_CONTAINMENT_REWRITE="0"),
        )

        self.assertEqual(code, 2, "instructive deny exits 2; stderr=%s" % stderr)
        expected_worktree = os.path.join(
            repo, ".dashclaw", "contained", server_ref[len("dashclaw/contained-"):]
        )
        self.assertTrue(os.path.isdir(expected_worktree))
        self.assertIn(server_ref, _worktree_list(repo))
        with open(self._action_state_path(tool_use_id), encoding="utf-8") as f:
            state = json.loads(f.read())
        self.assertEqual(state["containment_ref"], server_ref)

    def test_malformed_server_ref_falls_back_to_local_derivation(self):
        repo = self._new_repo()
        session_id = "sess-malref-" + uuid.uuid4().hex[:8]
        tool_use_id = "tu-malref-" + uuid.uuid4().hex[:8]
        self._action_state_path(tool_use_id)

        self.log.guard_response = {
            "decision": "allow_contained",
            "recorded": True,
            "action_id": "act-malref-1",
            "containment": {"status": "contained", "basis": "file", "ref": "refs/heads/main; rm -rf /"},
        }

        code, _, _ = _run_hook(
            {
                "tool_name": "Write",
                "tool_input": {"file_path": os.path.join(repo, "foo.txt"), "content": "hello"},
                "tool_use_id": tool_use_id,
                "session_id": session_id,
            },
            self._env(repo, DASHCLAW_CONTAINMENT_REWRITE="0"),
        )

        self.assertEqual(code, 2)
        with open(self._action_state_path(tool_use_id), encoding="utf-8") as f:
            state = json.loads(f.read())
        self.assertEqual(state["containment_ref"], "dashclaw/contained-" + self._contained_seg(session_id))


if __name__ == "__main__":
    unittest.main()
