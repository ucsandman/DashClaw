"""Tests for enforcement_liveness_probe.py (roadmap v8.2).

Contract under test: the probe reproduces the harness's hook contract around
the real installed command — timeout is SECONDS, seconds*1000 past int32
overflows the timer and cancels the hook (fail-open), exit 2 holds and
anything else proceeds — and verdicts by the witness file, never the ledger.

The seeded v4.72.1 regression is the acceptance test from the roadmap: a
settings.json carrying the exact overflowed timeout (3600000) must yield
verdict `executed` even when the hook itself would have blocked.
"""
import hashlib
import json
import os
import subprocess
import sys
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from tempfile import TemporaryDirectory
from unittest import mock

PROBE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "enforcement_liveness_probe.py")

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("DASHCLAW_DISABLE_DOTENV", "1")
from enforcement_liveness_probe import (  # noqa: E402
    default_settings_paths,
    effective_hook_timer,
    find_pretool_entries,
    measure_hook_metadata,
    parse_hooks_block_minimal,
)

# The hermes seam must be probeable on a BARE interpreter: the hook runs as
# plain `python`, which is not necessarily the one Hermes itself uses. CI's
# python has no PyYAML, which is exactly the environment worth testing.
try:
    import yaml as _yaml  # noqa: F401
    HAS_PYYAML = True
except ImportError:
    HAS_PYYAML = False

HERMES_SNIPPET = (
    "hooks:\n"
    "  pre_tool_call:\n"
    '    - matcher: "^(Bash|Edit|Write)$"\n'
    '      command: "python /repo/.hermes/hooks/dashclaw_pretool_hermes.py"\n'
    "      timeout: 60\n"
    "  on_session_start:\n"
    '    - command: "python /repo/hooks/enforcement_liveness_probe.py"\n'
    "      timeout: 10\n"
)


class TestMinimalYamlReader(unittest.TestCase):
    """The no-PyYAML fallback. It only has to read the block the installer
    writes — but on that block it must agree with PyYAML exactly, or the
    hermes verdict depends on which interpreter happened to run the hook."""

    def test_reads_the_installed_hooks_block(self):
        parsed = parse_hooks_block_minimal(HERMES_SNIPPET)
        entries = parsed["hooks"]["pre_tool_call"]
        self.assertEqual(len(entries), 1)
        self.assertEqual(entries[0]["command"], "python /repo/.hermes/hooks/dashclaw_pretool_hermes.py")
        self.assertEqual(entries[0]["timeout"], 60)
        self.assertEqual(entries[0]["matcher"], "^(Bash|Edit|Write)$")
        self.assertEqual(len(parsed["hooks"]["on_session_start"]), 1)

    @unittest.skipUnless(HAS_PYYAML, "PyYAML not installed")
    def test_agrees_with_pyyaml_on_that_block(self):
        import yaml
        self.assertEqual(parse_hooks_block_minimal(HERMES_SNIPPET)["hooks"], yaml.safe_load(HERMES_SNIPPET)["hooks"])

    def test_ignores_everything_outside_the_hooks_block(self):
        text = (
            "plugins:\n  dashclaw:\n    env:\n      DASHCLAW_BASE_URL: https://x\n"
            + HERMES_SNIPPET
            + "hooks_auto_accept: false\n"
        )
        parsed = parse_hooks_block_minimal(text)
        self.assertEqual(len(parsed["hooks"]["pre_tool_call"]), 1)
        self.assertNotIn("plugins", parsed)

    def test_refuses_rather_than_guesses_on_a_shape_it_cannot_read(self):
        # A wrong answer here is worse than no answer: it would silently
        # report a seam as uninstalled, or probe the wrong command.
        with self.assertRaises(ValueError):
            parse_hooks_block_minimal("hooks:\n\tpre_tool_call:\n\t  - command: x\n")
        with self.assertRaises(ValueError):
            parse_hooks_block_minimal("hooks:\n  pre_tool_call:\n    - just-a-scalar\n")

    def test_no_hooks_block_is_empty_not_an_error(self):
        self.assertEqual(parse_hooks_block_minimal("plugins:\n  dashclaw: {}\n"), {"hooks": {}})

    def test_unescapes_a_quoted_windows_command(self):
        # Regression: unwrapping the quotes without UNESCAPING them left every
        # backslash doubled, so the hook command could not run — and a hook
        # that cannot run reads as a seam that does not enforce. Caught by the
        # e2e hermes test on an interpreter without PyYAML.
        command = r'"C:\tools\python.exe" "C:\tmp\dashclaw_pretool_hermes.py" --agent-id hermes'
        doc = "hooks:\n  pre_tool_call:\n    - command: %s\n" % json.dumps(command)
        parsed = parse_hooks_block_minimal(doc)
        self.assertEqual(parsed["hooks"]["pre_tool_call"][0]["command"], command)

    def test_unescapes_a_single_quoted_scalar(self):
        parsed = parse_hooks_block_minimal("hooks:\n  pre_tool_call:\n    - command: 'it''s /bin/dashclaw_pretool'\n")
        self.assertEqual(parsed["hooks"]["pre_tool_call"][0]["command"], "it's /bin/dashclaw_pretool")


class TestEffectiveHookTimer(unittest.TestCase):
    def test_sane_timeout_does_not_overflow(self):
        seconds, ms, overflowed = effective_hook_timer(3660)
        self.assertEqual(seconds, 3660)
        self.assertEqual(ms, 3_660_000)
        self.assertFalse(overflowed)

    def test_v4721_seed_overflows(self):
        # The exact value every installer wrote before v4.72.1: milliseconds
        # in a seconds field. 3600000 * 1000 > 2^31-1 -> timer fires at once.
        seconds, ms, overflowed = effective_hook_timer(3600000)
        self.assertTrue(overflowed)
        self.assertEqual(ms, 3_600_000_000)

    def test_absent_and_garbage_fall_back_to_harness_default(self):
        for value in (None, "abc", "", -5, 0, float("nan")):
            seconds, ms, overflowed = effective_hook_timer(value)
            self.assertEqual(seconds, 600, value)
            self.assertFalse(overflowed, value)

    def test_overflow_boundary(self):
        self.assertFalse(effective_hook_timer(2_147_483)[2])   # 2^31-1 ms is ~2147483.6s
        self.assertTrue(effective_hook_timer(2_147_484)[2])


class TestFindPretoolEntries(unittest.TestCase):
    def test_finds_dashclaw_entry_and_ignores_others(self):
        with TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "settings.json")
            with open(path, "w", encoding="utf-8") as f:
                json.dump({"hooks": {"PreToolUse": [
                    {"matcher": "Bash", "hooks": [
                        {"type": "command", "command": "node run_hook.cjs dashclaw_pretool.py", "timeout": 3660},
                        {"type": "command", "command": "node some_other_hook.cjs"},
                    ]},
                ]}}, f)
            entries, problems = find_pretool_entries([path])
            self.assertEqual(len(entries), 1)
            self.assertEqual(entries[0]["timeout_seconds"], 3660)
            self.assertEqual(entries[0]["harness"], "claude-code")
            self.assertFalse(entries[0]["overflowed"])
            self.assertEqual(problems, [])

    def test_missing_file_is_silent_but_malformed_one_is_reported(self):
        # An absent config is an ordinary "not installed". A config that EXISTS
        # and cannot be parsed is a reason the seam could not be probed, and
        # swallowing it renders the same false "nothing installed" green.
        with TemporaryDirectory() as tmp:
            bad = os.path.join(tmp, "bad.json")
            with open(bad, "w", encoding="utf-8") as f:
                f.write("{not json")
            entries, problems = find_pretool_entries([bad, os.path.join(tmp, "absent.json")])
            self.assertEqual(entries, [])
            self.assertEqual(len(problems), 1)
            self.assertIn("bad.json", problems[0])

    def test_parses_the_codex_toml_seam(self):
        # The exact block `dashclaw install codex` writes into
        # ~/.codex/config.toml. `[[hooks.PreToolUse]]` +
        # `[[hooks.PreToolUse.hooks]]` decode to the same nesting the JSON
        # path walks, so only the parser differs.
        with TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "config.toml")
            with open(path, "w", encoding="utf-8") as f:
                f.write(
                    '[[hooks.PreToolUse]]\n'
                    'matcher = "Bash|Edit|Write|MultiEdit"\n'
                    '[[hooks.PreToolUse.hooks]]\n'
                    'type = "command"\n'
                    'command = "python /h/dashclaw_pretool.py --agent-id codex"\n'
                    'timeout = 3600\n'
                )
            entries, problems = find_pretool_entries([path])
            self.assertEqual(problems, [])
            self.assertEqual(len(entries), 1)
            self.assertEqual(entries[0]["harness"], "codex")
            self.assertEqual(entries[0]["timeout_seconds"], 3600)
            self.assertEqual(entries[0]["settings_path"], path)

    def test_parses_the_hermes_yaml_seam(self):
        # Hermes is FLATTER than the other two: the command sits on the
        # matcher entry itself (hooks.pre_tool_call[]), not in a second
        # array under it, and the event key is snake_case.
        with TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "config.yaml")
            with open(path, "w", encoding="utf-8") as f:
                f.write(
                    "hooks:\n"
                    "  pre_tool_call:\n"
                    '    - matcher: "^(Bash|Edit|Write)$"\n'
                    '      command: "python /repo/.hermes/hooks/dashclaw_pretool_hermes.py"\n'
                    "      timeout: 60\n"
                    "  on_session_start:\n"
                    '    - command: "python /repo/hooks/enforcement_liveness_probe.py"\n'
                )
            entries, problems = find_pretool_entries([path])
            self.assertEqual(problems, [])
            self.assertEqual(len(entries), 1)
            self.assertEqual(entries[0]["harness"], "hermes")
            self.assertEqual(entries[0]["timeout_seconds"], 60)

    def test_hermes_ignores_the_claude_code_event_key(self):
        # A YAML file carrying a PreToolUse key must not be read as a hermes
        # seam: the event names are not interchangeable.
        with TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "config.yaml")
            with open(path, "w", encoding="utf-8") as f:
                f.write('hooks:\n  PreToolUse:\n    - command: "python dashclaw_pretool.py"\n')
            entries, _ = find_pretool_entries([path])
            self.assertEqual(entries, [])

    def test_codex_timeout_never_emulates_the_claude_code_overflow(self):
        # The int32 timer overflow was observed on the Claude Code harness and
        # nowhere else. Asserting it for codex would render a live seam
        # `executed` on a large-but-legal timeout — a false RED invented from
        # an unverified contract.
        self.assertTrue(effective_hook_timer(3_600_000, "claude-code")[2])
        self.assertFalse(effective_hook_timer(3_600_000, "codex")[2])


class TestHookMetadata(unittest.TestCase):
    def _entry(self, hook_path):
        return {
            "command": '"%s" "%s" --agent-id codex' % (sys.executable, hook_path),
            "settings_path": os.path.join(os.path.dirname(hook_path), "config.toml"),
            "harness": "codex",
        }

    def test_fingerprint_tracks_the_selected_hook_file_bytes(self):
        with TemporaryDirectory() as tmp:
            hook = os.path.join(tmp, "dashclaw_pretool.py")
            with open(hook, "wb") as f:
                f.write(b"print('first')\n")
            first = measure_hook_metadata(self._entry(hook), tmp)

            with open(hook, "wb") as f:
                f.write(b"print('second')\n")
            second = measure_hook_metadata(self._entry(hook), tmp)

            self.assertRegex(first["hook_fingerprint"], r"^sha256:[0-9a-f]{64}$")
            self.assertNotEqual(first["hook_fingerprint"], second["hook_fingerprint"])
            self.assertNotIn(tmp, " ".join(second.values()))

    def test_fingerprint_follows_a_known_delegate_instead_of_the_launcher(self):
        with TemporaryDirectory() as tmp:
            launcher = os.path.join(tmp, "launcher.py")
            hook = os.path.join(tmp, "dashclaw_pretool.py")
            with open(launcher, "wb") as f:
                f.write(b"print('shim')\n")
            with open(hook, "wb") as f:
                f.write(b"print('enforcement v1')\n")
            entry = self._entry(hook)
            entry["command"] = '"%s" "%s" "%s"' % (sys.executable, launcher, hook)
            first = measure_hook_metadata(entry, tmp)

            with open(hook, "wb") as f:
                f.write(b"print('enforcement v2')\n")
            second = measure_hook_metadata(entry, tmp)

            self.assertNotEqual(first["hook_fingerprint"], second["hook_fingerprint"])

    def test_hermes_fingerprint_includes_the_canonical_delegate_bytes(self):
        with TemporaryDirectory() as tmp:
            adapter_dir = os.path.join(tmp, ".hermes", "hooks")
            canonical_dir = os.path.join(tmp, "hooks")
            os.makedirs(adapter_dir)
            os.makedirs(canonical_dir)
            adapter = os.path.join(adapter_dir, "dashclaw_pretool_hermes.py")
            canonical = os.path.join(canonical_dir, "dashclaw_pretool.py")
            with open(adapter, "wb") as f:
                f.write(b"adapter\n")
            with open(canonical, "wb") as f:
                f.write(b"canonical v1\n")
            entry = self._entry(adapter)
            entry["harness"] = "hermes"
            first = measure_hook_metadata(entry, tmp)

            with open(canonical, "wb") as f:
                f.write(b"canonical v2\n")
            second = measure_hook_metadata(entry, tmp)

            self.assertNotEqual(first["hook_fingerprint"], second["hook_fingerprint"])

    def test_malformed_version_output_is_unavailable_and_argv_is_bounded(self):
        with TemporaryDirectory() as tmp:
            hook = os.path.join(tmp, "dashclaw_pretool.py")
            with open(hook, "wb") as f:
                f.write(b"pass\n")
            completed = subprocess.CompletedProcess([], 0, stdout=b"definitely-not-a-version\n", stderr=b"")
            with mock.patch("enforcement_liveness_probe.shutil.which", return_value=sys.executable), \
                    mock.patch("enforcement_liveness_probe.subprocess.run", return_value=completed) as run:
                metadata = measure_hook_metadata(self._entry(hook), tmp)

            self.assertEqual(metadata["runtime_version"], "unavailable")
            argv = run.call_args.args[0]
            self.assertEqual(argv, [sys.executable, "--version"])
            self.assertFalse(run.call_args.kwargs.get("shell", False))
            self.assertLessEqual(run.call_args.kwargs["timeout"], 3)

    def test_version_timeout_returns_unavailable_with_a_fixed_bound(self):
        with TemporaryDirectory() as tmp:
            hook = os.path.join(tmp, "dashclaw_pretool.py")
            with open(hook, "wb") as f:
                f.write(b"pass\n")
            with mock.patch("enforcement_liveness_probe.shutil.which", return_value=sys.executable), \
                    mock.patch(
                        "enforcement_liveness_probe.subprocess.run",
                        side_effect=subprocess.TimeoutExpired([sys.executable, "--version"], 2),
                    ) as run:
                metadata = measure_hook_metadata(self._entry(hook), tmp)

            self.assertEqual(metadata["runtime_version"], "unavailable")
            self.assertRegex(metadata["hook_fingerprint"], r"^sha256:[0-9a-f]{64}$")
            self.assertLessEqual(run.call_args.kwargs["timeout"], 3)

    def test_runtime_version_comes_from_the_host_cli_not_the_hook_interpreter(self):
        with TemporaryDirectory() as tmp:
            hook = os.path.join(tmp, "dashclaw_pretool.py")
            with open(hook, "wb") as f:
                f.write(b"pass\n")
            completed = subprocess.CompletedProcess([], 0, stdout=b"codex-cli 0.153.4\n", stderr=b"")
            with mock.patch("enforcement_liveness_probe.shutil.which", return_value="C:/bin/codex.exe"), \
                    mock.patch("enforcement_liveness_probe.subprocess.run", return_value=completed) as run:
                metadata = measure_hook_metadata(self._entry(hook), tmp)

            self.assertEqual(metadata["runtime_version"], "codex-cli 0.153.4")
            self.assertEqual(run.call_args.args[0], ["C:/bin/codex.exe", "--version"])


class TestDefaultSettingsPaths(unittest.TestCase):
    def test_codex_resolves_to_its_own_config_not_claude_code(self):
        # The regression this fixes: every runtime resolved to
        # .claude/settings.json, so the codex-wired run drove the Claude Code
        # seam and filed the verdict as `runtime = codex`.
        with mock.patch.dict(os.environ, {"CODEX_HOME": os.path.join("C:", "cx")}):
            paths = default_settings_paths("/proj", "codex")
        self.assertEqual(len(paths), 1)
        self.assertTrue(paths[0].endswith("config.toml"))
        self.assertNotIn(".claude", paths[0])

    def test_hermes_resolves_to_its_own_config_yaml(self):
        with mock.patch.dict(os.environ, {"HERMES_HOME": os.path.join("C:", "hm")}):
            paths = default_settings_paths("/proj", "hermes")
        self.assertEqual(len(paths), 1)
        self.assertTrue(paths[0].endswith("config.yaml"))

    def test_claude_code_and_unknown_keep_the_settings_json_pair(self):
        for runtime in ("claude-code", "unknown"):
            paths = default_settings_paths("/proj", runtime)
            self.assertEqual(len(paths), 2, runtime)
            self.assertTrue(all(p.endswith("settings.json") for p in paths), runtime)


# ---------------------------------------------------------------------------
# End-to-end probe runs against a stub hook + stub API
# ---------------------------------------------------------------------------

STUB_EXIT_2 = "import sys; sys.stdin.read(); sys.stderr.write('[DashClaw] Blocked by policy: probe\\n'); sys.exit(2)"
STUB_EXIT_0 = "import sys; sys.stdin.read(); sys.exit(0)"
STUB_OBSERVE = "import sys; sys.stdin.read(); sys.stderr.write('[DashClaw] [observe] Would block: probe\\n'); sys.exit(0)"
# Hermes adapters answer on stdout and ALWAYS exit 0 — see
# .hermes/hooks/dashclaw_common.py (emit_block / emit_noop).
STUB_HERMES_BLOCK = (
    "import sys; sys.stdin.read(); "
    "sys.stdout.write('{\"decision\": \"block\", \"reason\": \"Blocked by DashClaw policy\"}'); sys.exit(0)"
)
STUB_HERMES_ALLOW = "import sys; sys.stdin.read(); sys.stdout.write('{}'); sys.exit(0)"


class _StubApi(BaseHTTPRequestHandler):
    reports = []
    latest_action = None  # dict or None

    def _send(self, code, body):
        data = json.dumps(body).encode("utf-8")
        self.send_response(code)
        self.send_header("content-type", "application/json")
        self.send_header("content-length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path.startswith("/api/actions"):
            actions = [self.latest_action] if self.latest_action else []
            return self._send(200, {"actions": actions})
        return self._send(404, {})

    def do_POST(self):
        length = int(self.headers.get("content-length", 0))
        body = json.loads(self.rfile.read(length) or b"{}")
        if self.path == "/api/enforcement-liveness":
            type(self).reports.append(body)
            return self._send(201, {"id": "elr_test"})
        return self._send(404, {})

    def do_PATCH(self):
        length = int(self.headers.get("content-length", 0))
        self.rfile.read(length)
        return self._send(200, {"ok": True})

    def log_message(self, *args):
        pass


class ProbeE2E(unittest.TestCase):
    def setUp(self):
        _StubApi.reports = []
        _StubApi.latest_action = None
        self.server = HTTPServer(("127.0.0.1", 0), _StubApi)
        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        self.base_url = "http://127.0.0.1:%d" % self.server.server_address[1]

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()

    def _write_fixture(self, tmp, stub_code, timeout):
        stub = os.path.join(tmp, "stub_hook.py")
        with open(stub, "w", encoding="utf-8") as f:
            f.write(stub_code + "\n")
        settings = os.path.join(tmp, "settings.json")
        entry = {"type": "command", "command": '"%s" "%s" dashclaw_pretool.py' % (sys.executable, stub)}
        if timeout is not None:
            entry["timeout"] = timeout
        with open(settings, "w", encoding="utf-8") as f:
            json.dump({"hooks": {"PreToolUse": [{"matcher": ".*", "hooks": [entry]}]}}, f)
        # The stub must run regardless of the trailing dashclaw_pretool.py arg;
        # make it a real no-op arg by having the stub ignore argv.
        return settings

    def _write_codex_fixture(self, tmp, stub_code, timeout):
        """The codex seam: the same stub hook declared in TOML, the shape
        `dashclaw install codex` writes into ~/.codex/config.toml."""
        stub = os.path.join(tmp, "stub_hook.py")
        with open(stub, "w", encoding="utf-8") as f:
            f.write(stub_code + "\n")
        config = os.path.join(tmp, "config.toml")
        command = '"%s" "%s" dashclaw_pretool.py' % (sys.executable, stub)
        with open(config, "w", encoding="utf-8") as f:
            f.write(
                '[[hooks.PreToolUse]]\n'
                'matcher = "Bash|Edit|Write|MultiEdit"\n'
                '[[hooks.PreToolUse.hooks]]\n'
                'type = "command"\n'
                'command = %s\n'
                'timeout = %d\n' % (json.dumps(command), timeout)
            )
        return config

    def _write_hermes_fixture(self, tmp, stub_code):
        """The hermes seam: flat matcher entries under `pre_tool_call`, the
        shape scripts/install-hermes-plugin.* append to ~/.hermes/config.yaml."""
        stub = os.path.join(tmp, "stub_hook.py")
        with open(stub, "w", encoding="utf-8") as f:
            f.write(stub_code + "\n")
        config = os.path.join(tmp, "config.yaml")
        command = '"%s" "%s" dashclaw_pretool_hermes.py' % (sys.executable, stub)
        with open(config, "w", encoding="utf-8") as f:
            f.write(
                "hooks:\n"
                "  pre_tool_call:\n"
                "    - matcher: \"^(Bash|Edit|Write|MultiEdit)$\"\n"
                "      command: %s\n"
                "      timeout: 60\n" % json.dumps(command)
            )
        return config

    def _run_probe(self, settings, tmp, extra_env=None, runtime=None, max_wait="30"):
        env = {**os.environ, "DASHCLAW_DISABLE_DOTENV": "1",
               "DASHCLAW_BASE_URL": self.base_url, "DASHCLAW_API_KEY": "test-key"}
        for k in ("DASHCLAW_URL", "DASHCLAW_HOOK_MODE", "DASHCLAW_LIVENESS_PROBE_DISABLED"):
            env.pop(k, None)
        env.update(extra_env or {})
        argv = [sys.executable, PROBE,
                "--witness-dir", os.path.join(tmp, "witness"), "--source", "ci", "--max-wait", max_wait]
        if settings is not None:
            argv += ["--settings", settings]
        if runtime is not None:
            argv += ["--runtime", runtime]
        return subprocess.run(argv, capture_output=True, env=env, timeout=60, text=True)

    def test_seeded_v4721_timeout_yields_executed(self):
        """THE regression test: the exact v4.72.1 config (timeout 3600000)
        must produce verdict `executed` even though the hook would block."""
        with TemporaryDirectory() as tmp:
            settings = self._write_fixture(tmp, STUB_EXIT_2, timeout=3600000)
            proc = self._run_probe(settings, tmp)
            self.assertEqual(proc.returncode, 1, proc.stdout + proc.stderr)
            self.assertEqual(len(_StubApi.reports), 1)
            run = _StubApi.reports[0]
            self.assertEqual(run["verdict"], "executed")
            self.assertTrue(run["hook"]["overflowed"])
            self.assertTrue(run["hook"]["cancelled"])
            self.assertTrue(run["witness"]["executed"])
            self.assertIn("v4.72.1", run["detail"])
            # The per-run witness dir (and file) is cleaned up after the run;
            # only the empty configured root may remain.
            root = os.path.join(tmp, "witness")
            leftovers = [os.path.join(d, f) for d, _, files in os.walk(root) for f in files]
            self.assertEqual(leftovers, [])

    def test_blocking_hook_with_sane_timeout_yields_held(self):
        with TemporaryDirectory() as tmp:
            settings = self._write_fixture(tmp, STUB_EXIT_2, timeout=3660)
            proc = self._run_probe(settings, tmp)
            self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
            run = _StubApi.reports[0]
            self.assertEqual(run["verdict"], "held")
            self.assertFalse(run["witness"]["executed"])
            self.assertEqual(run["hook"]["exit_code"], 2)

    def test_metadata_describes_the_later_entry_that_actually_held(self):
        with TemporaryDirectory() as tmp:
            first_dir = os.path.join(tmp, "first")
            second_dir = os.path.join(tmp, "second")
            os.makedirs(first_dir)
            os.makedirs(second_dir)
            first = os.path.join(first_dir, "dashclaw_pretool.py")
            second = os.path.join(second_dir, "dashclaw_pretool.py")
            first_bytes = (STUB_EXIT_0 + "\n").encode("utf-8")
            second_bytes = (STUB_EXIT_2 + "\n").encode("utf-8")
            with open(first, "wb") as f:
                f.write(first_bytes)
            with open(second, "wb") as f:
                f.write(second_bytes)
            settings = os.path.join(tmp, "settings.json")
            with open(settings, "w", encoding="utf-8") as f:
                json.dump({"hooks": {"PreToolUse": [{"matcher": ".*", "hooks": [
                    {"type": "command", "command": '"%s" "%s"' % (sys.executable, first), "timeout": 3660},
                    {"type": "command", "command": '"%s" "%s"' % (sys.executable, second), "timeout": 120},
                ]}]}}, f)

            proc = self._run_probe(settings, tmp)

            self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
            run = _StubApi.reports[0]
            self.assertEqual(run["verdict"], "held")
            self.assertEqual(run["hook"]["timeout_seconds"], 120)
            self.assertEqual(
                run["hook"]["hook_fingerprint"],
                "sha256:" + hashlib.sha256(second_bytes).hexdigest(),
            )

    def test_metadata_and_exit_code_describe_a_hung_entry_before_a_later_allow(self):
        with TemporaryDirectory() as tmp:
            first_dir = os.path.join(tmp, "first")
            second_dir = os.path.join(tmp, "second")
            os.makedirs(first_dir)
            os.makedirs(second_dir)
            first = os.path.join(first_dir, "dashclaw_pretool.py")
            second = os.path.join(second_dir, "dashclaw_pretool.py")
            first_bytes = b"import time; time.sleep(2)\n"
            with open(first, "wb") as f:
                f.write(first_bytes)
            with open(second, "w", encoding="utf-8") as f:
                f.write(STUB_EXIT_0 + "\n")
            settings = os.path.join(tmp, "settings.json")
            with open(settings, "w", encoding="utf-8") as f:
                json.dump({"hooks": {"PreToolUse": [{"matcher": ".*", "hooks": [
                    {"type": "command", "command": '"%s" "%s"' % (sys.executable, first), "timeout": 3660},
                    {"type": "command", "command": '"%s" "%s"' % (sys.executable, second), "timeout": 120},
                ]}]}}, f)

            proc = self._run_probe(settings, tmp, max_wait="0.1")

            self.assertEqual(proc.returncode, 1, proc.stdout + proc.stderr)
            run = _StubApi.reports[0]
            self.assertEqual(run["verdict"], "unprovable")
            self.assertNotIn("exit_code", run["hook"])
            self.assertEqual(run["hook"]["timeout_seconds"], 3660)
            self.assertEqual(
                run["hook"]["hook_fingerprint"],
                "sha256:" + hashlib.sha256(first_bytes).hexdigest(),
            )

    def test_metadata_describes_a_cancelled_entry_before_a_later_allow(self):
        with TemporaryDirectory() as tmp:
            first_dir = os.path.join(tmp, "first")
            second_dir = os.path.join(tmp, "second")
            os.makedirs(first_dir)
            os.makedirs(second_dir)
            first = os.path.join(first_dir, "dashclaw_pretool.py")
            second = os.path.join(second_dir, "dashclaw_pretool.py")
            first_bytes = (STUB_EXIT_2 + "\n").encode("utf-8")
            with open(first, "wb") as f:
                f.write(first_bytes)
            with open(second, "w", encoding="utf-8") as f:
                f.write(STUB_EXIT_0 + "\n")
            settings = os.path.join(tmp, "settings.json")
            with open(settings, "w", encoding="utf-8") as f:
                json.dump({"hooks": {"PreToolUse": [{"matcher": ".*", "hooks": [
                    {"type": "command", "command": '"%s" "%s"' % (sys.executable, first), "timeout": 3600000},
                    {"type": "command", "command": '"%s" "%s"' % (sys.executable, second), "timeout": 120},
                ]}]}}, f)

            proc = self._run_probe(settings, tmp)

            self.assertEqual(proc.returncode, 1, proc.stdout + proc.stderr)
            run = _StubApi.reports[0]
            self.assertEqual(run["verdict"], "executed")
            self.assertTrue(run["hook"]["cancelled"])
            self.assertTrue(run["hook"]["overflowed"])
            self.assertEqual(run["hook"]["timeout_seconds"], 3600000)
            self.assertNotIn("exit_code", run["hook"])
            self.assertEqual(
                run["hook"]["hook_fingerprint"],
                "sha256:" + hashlib.sha256(first_bytes).hexdigest(),
            )

    def test_codex_toml_seam_is_driven_end_to_end(self):
        """The codex seam reports on ITS OWN config. Before this the probe
        parsed JSON only, so a `--runtime codex` run drove whatever was in
        .claude/settings.json and filed the verdict under the codex name."""
        with TemporaryDirectory() as tmp:
            config = self._write_codex_fixture(tmp, STUB_EXIT_2, timeout=3600)
            proc = self._run_probe(config, tmp, runtime="codex")
            self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
            run = _StubApi.reports[0]
            self.assertEqual(run["runtime"], "codex")
            self.assertEqual(run["verdict"], "held")
            self.assertEqual(run["hook"]["settings_path"], config)
            self.assertEqual(run["hook"]["exit_code"], 2)

    def test_hermes_stdout_veto_is_read_as_held(self):
        """THE hermes acceptance test. Its adapter exits 0 whether it blocked
        or not and answers on stdout, so an exit-code reading would score this
        exact run as `executed` — reporting a WORKING seam as broken."""
        with TemporaryDirectory() as tmp:
            config = self._write_hermes_fixture(tmp, STUB_HERMES_BLOCK)
            proc = self._run_probe(config, tmp, runtime="hermes")
            self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
            run = _StubApi.reports[0]
            self.assertEqual(run["runtime"], "hermes")
            self.assertEqual(run["verdict"], "held")
            self.assertFalse(run["witness"]["executed"])
            # Exit code 0 AND held — the pairing that proves the per-harness
            # signal is in use rather than the exit-2 default.
            self.assertEqual(run["hook"]["exit_code"], 0)

    def test_hermes_allow_response_executes_the_witness(self):
        with TemporaryDirectory() as tmp:
            config = self._write_hermes_fixture(tmp, STUB_HERMES_ALLOW)
            proc = self._run_probe(config, tmp, runtime="hermes")
            self.assertEqual(proc.returncode, 1, proc.stdout + proc.stderr)
            run = _StubApi.reports[0]
            self.assertEqual(run["runtime"], "hermes")
            self.assertTrue(run["witness"]["executed"])
            self.assertIn(run["verdict"], ("executed", "unprovable"))

    def test_codex_runtime_never_falls_back_to_the_claude_code_seam(self):
        """The regression guard. With no codex config present the verdict is
        `unprovable` naming config.toml — NOT a green borrowed from a healthy
        Claude Code hook that happens to be installed on the same machine."""
        with TemporaryDirectory() as tmp:
            # A healthy Claude Code seam exists in this project root. It must
            # not be able to answer for codex.
            claude_dir = os.path.join(tmp, "proj", ".claude")
            os.makedirs(claude_dir)
            self._write_fixture(tmp, STUB_EXIT_2, timeout=3660)
            with open(os.path.join(claude_dir, "settings.json"), "w", encoding="utf-8") as f:
                json.dump({"hooks": {"PreToolUse": [{"matcher": ".*", "hooks": [
                    {"type": "command",
                     "command": '"%s" "%s" dashclaw_pretool.py' % (sys.executable, os.path.join(tmp, "stub_hook.py")),
                     "timeout": 3660},
                ]}]}}, f)
            proc = self._run_probe(None, tmp, runtime="codex", extra_env={
                "CODEX_HOME": os.path.join(tmp, "empty-codex-home"),
                "CLAUDE_PROJECT_DIR": os.path.join(tmp, "proj"),
            })
            self.assertEqual(proc.returncode, 1, proc.stdout + proc.stderr)
            run = _StubApi.reports[0]
            self.assertEqual(run["runtime"], "codex")
            self.assertEqual(run["verdict"], "unprovable")
            self.assertIn("config.toml", run["detail"])
            self.assertIn("dashclaw install codex", run["detail"])

    def test_allow_decision_yields_unprovable(self):
        _StubApi.latest_action = {"id": "act_1", "status": "running"}
        with TemporaryDirectory() as tmp:
            settings = self._write_fixture(tmp, STUB_EXIT_0, timeout=3660)
            proc = self._run_probe(settings, tmp)
            self.assertEqual(proc.returncode, 1)
            run = _StubApi.reports[0]
            self.assertEqual(run["verdict"], "unprovable")
            self.assertTrue(run["witness"]["executed"])
            self.assertIn("No policy held", run["detail"])

    def test_seam_broken_above_guard_yields_executed(self):
        # Guard recorded a block, but the hook exited 0: fail-open above guard.
        _StubApi.latest_action = {"id": "act_2", "status": "blocked"}
        with TemporaryDirectory() as tmp:
            settings = self._write_fixture(tmp, STUB_EXIT_0, timeout=3660)
            proc = self._run_probe(settings, tmp)
            self.assertEqual(proc.returncode, 1)
            run = _StubApi.reports[0]
            self.assertEqual(run["verdict"], "executed")
            self.assertIn("broken above the guard", run["detail"])

    def test_observe_mode_yields_unprovable(self):
        with TemporaryDirectory() as tmp:
            settings = self._write_fixture(tmp, STUB_OBSERVE, timeout=3660)
            proc = self._run_probe(settings, tmp)
            self.assertEqual(proc.returncode, 1)
            run = _StubApi.reports[0]
            self.assertEqual(run["verdict"], "unprovable")
            self.assertIn("observe mode", run["detail"])

    def test_no_hook_installed_yields_unprovable(self):
        with TemporaryDirectory() as tmp:
            settings = os.path.join(tmp, "settings.json")
            with open(settings, "w", encoding="utf-8") as f:
                json.dump({"hooks": {}}, f)
            proc = self._run_probe(settings, tmp)
            self.assertEqual(proc.returncode, 1)
            run = _StubApi.reports[0]
            self.assertEqual(run["verdict"], "unprovable")
            self.assertIn("ungoverned", run["detail"])

    def test_disabled_env_exits_zero_without_reporting(self):
        with TemporaryDirectory() as tmp:
            settings = self._write_fixture(tmp, STUB_EXIT_2, timeout=3660)
            proc = self._run_probe(settings, tmp, extra_env={"DASHCLAW_LIVENESS_PROBE_DISABLED": "1"})
            self.assertEqual(proc.returncode, 0)
            self.assertEqual(_StubApi.reports, [])


if __name__ == "__main__":
    unittest.main()


class TestSessionStartSpawn(unittest.TestCase):
    """SessionStart entry point (v5, re-homed from the retired session-digest
    hook): throttle to once/12h via a marker file and run the probe in a
    DETACHED child so session start is never delayed."""

    def setUp(self):
        import enforcement_liveness_probe as probe
        self.probe = probe
        self._tmp = TemporaryDirectory()
        self.home = os.path.join(self._tmp.name, "home")
        for k in ("DASHCLAW_LIVENESS_PROBE_DISABLED", "DASHCLAW_LIVENESS_PROBE_SPAWNED"):
            os.environ.pop(k, None)

    def tearDown(self):
        self._tmp.cleanup()

    def _expanduser(self, p):
        return self.home if p == "~" else p

    def _marker(self):
        return os.path.join(self.home, ".dashclaw", "liveness-probe", ".last-spawn")

    def test_throttled_by_fresh_marker(self):
        os.makedirs(os.path.dirname(self._marker()))
        with open(self._marker(), "w", encoding="utf-8") as f:
            f.write("now")
        calls = []
        with mock.patch.object(os.path, "expanduser", self._expanduser), \
                mock.patch.object(self.probe.subprocess, "Popen", lambda *a, **k: calls.append(a)):
            self.probe._throttle_and_detach_session_start()
        self.assertEqual(calls, [])

    def test_fires_detached_and_writes_marker(self):
        calls = []
        with mock.patch.object(os.path, "expanduser", self._expanduser), \
                mock.patch.object(self.probe.subprocess, "Popen", lambda *a, **k: calls.append((a, k))):
            self.probe._throttle_and_detach_session_start()
        self.assertEqual(len(calls), 1)
        argv = calls[0][0][0]
        self.assertTrue(argv[1].endswith("enforcement_liveness_probe.py"))
        self.assertEqual(argv[2:], ["--source", "session-start"])
        # The detached child carries the SPAWNED flag so it runs the probe body
        # inline instead of re-spawning (no infinite loop).
        self.assertEqual(calls[0][1]["env"].get("DASHCLAW_LIVENESS_PROBE_SPAWNED"), "1")
        self.assertTrue(os.path.exists(self._marker()))


class TestProbeIdentityRewrite(unittest.TestCase):
    def test_replaces_installed_agent_id(self):
        from enforcement_liveness_probe import command_with_probe_identity
        cmd = 'python "C:/x/hooks/dashclaw_pretool.py" --agent-id claude-code'
        out = command_with_probe_identity(cmd)
        self.assertIn("--agent-id smoke-liveness-probe", out)
        self.assertNotIn("claude-code", out)

    def test_replaces_equals_form_and_appends_when_absent(self):
        from enforcement_liveness_probe import command_with_probe_identity
        self.assertIn("--agent-id smoke-liveness-probe",
                      command_with_probe_identity("node run_hook.cjs dashclaw_pretool.py --agent-id=codex"))
        appended = command_with_probe_identity("node run_hook.cjs dashclaw_pretool.py")
        self.assertTrue(appended.endswith("--agent-id smoke-liveness-probe"))
