"""Shell command parser for dashclaw-agent-intel.

Extracts structured metadata from shell command strings:
base command, subcommands, flags, targets, wrappers, pipes,
redirections, and chained commands.

Uses only the Python standard library.
"""

import re
import shlex
from typing import Optional

# Leading KEY=VALUE environment assignments (`FOO=1 BAR=2 cmd ...`). Without
# stripping these, the first assignment becomes base_command and the whole
# command classifies as "unknown" — which inflates risk to the blunt Bash
# base instead of the real command's intent.
_ENV_ASSIGNMENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*=")

# Commands whose first positional argument is a subcommand.
SUBCOMMAND_TOOLS = frozenset({
    "git", "docker", "kubectl", "npm", "yarn", "pip",
    "cargo", "go", "apt", "brew", "systemctl",
})

# Per-tool global flags that take a SEPARATE value token. Subcommand detection
# must consume both, or the value (`-C C:/Projects/x`) gets read as the
# subcommand. Inline `--flag=value` forms need no entry — they are one token.
# ponytail: git only, because git is the tool whose missing subcommand has a
# dangerous default (`_classify_git` falls through to "write"). Add a tool here
# when its global flags are shown to mis-key a real command, not before.
_GLOBAL_VALUE_FLAGS: dict[str, frozenset] = {
    "git": frozenset({
        "-C", "-c", "--git-dir", "--work-tree",
        "--namespace", "--exec-path", "--config-env", "--super-prefix",
    }),
}

# Wrappers that prefix the real command.
#
# A wrapper NOT listed here shadows the command it wraps: the parser reports the
# wrapper as base_command, the classifier grades the result `unknown`, and the
# hook floors `unknown` at the Bash tool's blunt base risk of 70. `rtk` (a
# token-compression proxy installed as a Claude Code PreToolUse hook that
# rewrites every Bash command to `rtk <cmd>`) made that failure universal on any
# machine running it — `rtk rm -rf /` graded 70 instead of destructive 100, and
# a read-only `rtk git log` graded 70 and typed `other` instead of readonly /
# `review`, which is what buried operators in approvals for read-only commands.
#
# ponytail: this stays an explicit allowlist. An unlisted wrapper still shadows
# its command; generic "unwrap anything whose first argument looks like a
# command" heuristics misfire on remote-exec forms (`ssh host rm -rf /`) where
# the wrapper, not the inner command, is the thing worth grading. Add entries
# as real wrappers show up.
WRAPPERS = frozenset({
    "sudo", "env", "nohup", "nice", "ionice",
    "strace", "time", "timeout", "rtk",
})

# Redirection operators, ordered longest-first so we greedily match.
_REDIR_OPS = ("&>>", "&>", "2>>", "2>", ">>", ">")


def _split_on_unquoted(command_str: str, delimiters: list[str]) -> list[tuple[str, str]]:
    """Split *command_str* on unquoted *delimiters*.

    Returns a list of (segment_text, delimiter_used) tuples.
    The last segment's delimiter is always the empty string.
    """
    segments: list[tuple[str, str]] = []
    in_single = False
    in_double = False
    buf: list[str] = []
    i = 0
    while i < len(command_str):
        ch = command_str[i]

        # Track quoting state.
        if ch == "'" and not in_double:
            in_single = not in_single
            buf.append(ch)
            i += 1
            continue
        if ch == '"' and not in_single:
            in_double = not in_double
            buf.append(ch)
            i += 1
            continue

        if not in_single and not in_double:
            # Try each delimiter (longest-first is important when
            # delimiters share prefixes, but our callers sort that).
            matched = False
            for delim in delimiters:
                if command_str[i:i + len(delim)] == delim:
                    segments.append(("".join(buf), delim))
                    buf = []
                    i += len(delim)
                    matched = True
                    break
            if matched:
                continue

        buf.append(ch)
        i += 1

    segments.append(("".join(buf), ""))
    return segments


def _tokenize(segment: str) -> list[str]:
    """Tokenize a shell segment using shlex, falling back on split."""
    segment = segment.strip()
    if not segment:
        return []
    try:
        return shlex.split(segment)
    except ValueError:
        # Unbalanced quotes, etc. -- best-effort.
        return segment.split()


def _is_fd_dup(target: str) -> bool:
    """True when a redirection target is a file descriptor, not a file.

    `2>&1` and `>&2` duplicate a descriptor; nothing is written to disk. Reading
    the `&1` as a filename made the most common idiom in the corpus look like a
    file write, which floored its risk at 35 in dashclaw_pretool and surfaced
    the shape `other -> &1` in the /policies review feed as something an
    operator could grant. `&>file` is unaffected: there the `&` belongs to the
    operator, so the target is `file`.
    """
    return target.startswith("&")


def _extract_redirections(tokens: list[str]) -> tuple[list[str], list[dict]]:
    """Separate redirection operators and their targets from *tokens*.

    Returns (remaining_tokens, redirections).
    """
    remaining: list[str] = []
    redirections: list[dict] = []
    i = 0
    while i < len(tokens):
        tok = tokens[i]
        matched_op: Optional[str] = None

        # Check if the token *is* a redirection operator.
        for op in _REDIR_OPS:
            if tok == op:
                matched_op = op
                break

        # Check if the token *starts with* a redirection operator
        # (e.g. ">output.txt" as one token).
        if matched_op is None:
            for op in _REDIR_OPS:
                if tok.startswith(op) and len(tok) > len(op):
                    target = tok[len(op):]
                    if not _is_fd_dup(target):
                        redirections.append({"type": op, "target": target})
                    i += 1
                    break
            else:
                if matched_op is None:
                    remaining.append(tok)
                i += 1
            continue

        # The operator is a standalone token.  Next token is the target.
        if i + 1 < len(tokens):
            target = tokens[i + 1]
            if not _is_fd_dup(target):
                redirections.append({"type": matched_op, "target": target})
            i += 2
        else:
            # Dangling operator -- keep it as-is.
            remaining.append(tok)
            i += 1

    return remaining, redirections


def _skip_wrapper_args(wrapper: str, tokens: list[str]) -> list[str]:
    """Consume flag-like arguments that belong to the *wrapper*, returning
    the remaining tokens that represent the wrapped command.

    Each wrapper has slightly different syntax, so we use simple heuristics:
    - ``sudo``: skip flags (starting with ``-``) until a non-flag token.
    - ``env``: skip ``KEY=VAL`` pairs and flags until a non-flag,
      non-assignment token.
    - ``nice`` / ``ionice``: skip ``-<flag> <value>`` pairs.
    - ``timeout``: skip flags then skip the duration argument.
    - ``nohup`` / ``time`` / ``strace``: skip flags.
    - ``rtk``: skip flags, then the ``proxy`` pass-through token if present.
    """
    i = 0
    if wrapper == "env":
        while i < len(tokens):
            if tokens[i].startswith("-") or "=" in tokens[i]:
                i += 1
            else:
                break
    elif wrapper in ("nice", "ionice"):
        while i < len(tokens) and tokens[i].startswith("-"):
            i += 1
            # Skip the value that follows the flag (e.g. -n 10, -c 2).
            if i < len(tokens) and not tokens[i].startswith("-"):
                i += 1
    elif wrapper == "timeout":
        # Skip flags, then skip the duration positional.
        while i < len(tokens) and tokens[i].startswith("-"):
            i += 1
        if i < len(tokens):
            # The next token is the duration.
            i += 1
    elif wrapper == "strace":
        while i < len(tokens) and tokens[i].startswith("-"):
            i += 1
    elif wrapper == "sudo":
        while i < len(tokens) and tokens[i].startswith("-"):
            i += 1
    elif wrapper in ("nohup", "time"):
        while i < len(tokens) and tokens[i].startswith("-"):
            i += 1
    elif wrapper == "rtk":
        while i < len(tokens) and tokens[i].startswith("-"):
            i += 1
        # `rtk proxy <cmd>` runs <cmd> unfiltered — one more token to skip.
        if i < len(tokens) and tokens[i] == "proxy":
            i += 1
    return tokens[i:]


def _parse_segment(tokens: list[str]) -> dict:
    """Parse a list of tokens into the structured result dict.

    This handles one logical command (no pipes, no chains).
    """
    result: dict = {
        "base_command": "",
        "subcommand": None,
        "flags": [],
        "targets": [],
        "wrapper": None,
        "env_assignments": [],
        "pipes": [],
        "redirections": [],
        "chains": [],
    }

    if not tokens:
        return result

    # Strip redirections first.
    tokens, redirections = _extract_redirections(tokens)
    result["redirections"] = redirections

    if not tokens:
        return result

    # Strip leading KEY=VALUE assignments so `FOO=1 BAR=2 cmd` classifies as
    # `cmd`. They are kept in env_assignments, never in targets, so a fake
    # credential value in the prefix cannot trip the sensitive-target boost.
    while tokens and _ENV_ASSIGNMENT_RE.match(tokens[0]):
        result["env_assignments"].append(tokens.pop(0))

    if not tokens:
        return result

    # Detect wrapper.
    idx = 0
    if tokens[idx] in WRAPPERS:
        result["wrapper"] = tokens[idx]
        remaining = _skip_wrapper_args(tokens[idx], tokens[idx + 1:])
        tokens = remaining
        if not tokens:
            return result
        idx = 0

    # Base command.
    result["base_command"] = tokens[idx]
    rest = tokens[idx + 1:]

    # Detect subcommand, looking PAST the tool's own global flags.
    #
    # `git -C <path> log` used to leave subcommand None, and _classify_git's
    # "unknown git subcommand -> write" safe default then graded a read-only log
    # as a write (action_type apply, server base 60 instead of review's 10).
    # That is the shape of every command in the 2026-08-16 interruption
    # incident, where the operator disabled the org's whole policy set.
    if result["base_command"] in SUBCOMMAND_TOOLS and rest:
        value_flags = _GLOBAL_VALUE_FLAGS.get(result["base_command"], frozenset())
        skipped: list[str] = []
        j = 0
        while j < len(rest) and rest[j].startswith("-"):
            skipped.append(rest[j])
            # A flag that takes a SEPARATE value consumes it too, so the value
            # (`-C C:/Projects/x`) is never mistaken for the subcommand.
            if rest[j] in value_flags and j + 1 < len(rest):
                skipped.append(rest[j + 1])
                j += 2
            else:
                j += 1
        if j < len(rest):
            result["subcommand"] = rest[j]
            # Global flags stay visible to the classifiers as flags; only the
            # subcommand itself is removed from the tail.
            rest = skipped + rest[j + 1:]

    # Classify remaining tokens as flags or targets.
    for tok in rest:
        if tok.startswith("-"):
            result["flags"].append(tok)
        else:
            result["targets"].append(tok)

    return result


def split_chain_texts(command_str: str) -> list[str]:
    """Split a command on unquoted sequential operators (&&, ||, ;, newline)
    into the raw text of each segment. Public so the classifier can grade every
    segment of a chain, not just the first (a `cd /p && rm -rf /` must classify
    as rm). `||` and a newline separate sequential commands just as `;`/`&&` do
    — a later segment still runs, so its risk must count and the static
    var-resolver must see earlier segments (evasion audit round 2, 2026-08-08)."""
    chain_segments = _split_on_unquoted(command_str, ["&&", "||", ";", "\n"])
    chain_texts = [seg for seg, _delim in chain_segments]
    return [t.strip() for t in chain_texts if t.strip()]


def parse_command(command_str: str) -> dict:
    """Parse a shell command string into structured metadata.

    Returns a dict with the following keys:
        base_command  (str)           – the primary executable
        subcommand    (str | None)    – e.g. "push" for "git push"
        flags         (list[str])     – tokens starting with "-"
        targets       (list[str])     – positional arguments
        wrapper       (str | None)    – sudo, env, nohup, etc.
        pipes         (list[dict])    – parsed segments for each pipe stage
        redirections  (list[dict])    – {"type": ">", "target": "file"}
        chains        (list[dict])    – parsed segments for && / ; chains
    """
    if not command_str or not command_str.strip():
        return {
            "base_command": "",
            "subcommand": None,
            "flags": [],
            "targets": [],
            "wrapper": None,
            "env_assignments": [],
            "pipes": [],
            "redirections": [],
            "chains": [],
        }

    # --- 1. Split on chains (&&, ;) first. ---
    chain_texts = split_chain_texts(command_str)

    if len(chain_texts) > 1:
        chains: list[dict] = []
        for ct in chain_texts:
            parsed = parse_command(ct)
            chains.append(parsed)

        # Top-level fields mirror the first chain segment.
        first = chains[0]
        return {
            "base_command": first["base_command"],
            "subcommand": first["subcommand"],
            "flags": first["flags"],
            "targets": first["targets"],
            "wrapper": first["wrapper"],
            "env_assignments": first["env_assignments"],
            "pipes": first["pipes"],
            "redirections": first["redirections"],
            "chains": chains,
        }

    # --- 2. Split on pipes (|) ---
    pipe_segments = _split_on_unquoted(command_str, ["|"])
    pipe_texts = [seg for seg, _delim in pipe_segments]
    pipe_texts = [t.strip() for t in pipe_texts if t.strip()]

    if len(pipe_texts) > 1:
        pipes: list[dict] = []
        for pt in pipe_texts:
            tokens = _tokenize(pt)
            parsed = _parse_segment(tokens)
            pipes.append(parsed)

        first = pipes[0]
        return {
            "base_command": first["base_command"],
            "subcommand": first["subcommand"],
            "flags": first["flags"],
            "targets": first["targets"],
            "wrapper": first["wrapper"],
            "env_assignments": first["env_assignments"],
            "pipes": pipes,
            "redirections": first["redirections"],
            "chains": [],
        }

    # --- 3. Single command ---
    tokens = _tokenize(command_str)
    result = _parse_segment(tokens)
    result["pipes"] = []
    result["chains"] = []
    return result
